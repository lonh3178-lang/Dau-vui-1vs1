# Đấu Vui 1v1 — hướng dẫn chạy online

Đây là bản web mẫu HTML/CSS/JavaScript dùng **Firebase Authentication (anonymous)** và **Firebase Realtime Database** để hai điện thoại nhìn thấy cùng phòng và tiến trình trận đấu theo thời gian thực.

## 1. Cần chuẩn bị
- Tài khoản Google
- Trình duyệt web
- Máy tính sẽ tiện hơn để cấu hình, nhưng có thể làm trên điện thoại ở chế độ trang web máy tính.

## 2. Tạo Firebase backend
1. Mở https://console.firebase.google.com/ và tạo project.
2. Trong Project settings, thêm ứng dụng Web (biểu tượng `</>`), đăng ký ứng dụng.
3. Sao chép `firebaseConfig` mà Firebase cung cấp.
4. Vào **Build → Authentication → Sign-in method**, bật **Anonymous**.
5. Vào **Build → Realtime Database → Create Database**. Chọn vùng gần người chơi. Khi tạo xong, sao chép URL database.
6. Mở `index.html`, tìm `const firebaseConfig = { ... }`, thay các giá trị `PASTE_...` bằng đúng cấu hình Firebase của ông. Không đổi tên trường.

## 3. Quy tắc database cho bản thử nghiệm
Trong Realtime Database → Rules, có thể dùng quy tắc thử nghiệm sau khi bật Anonymous Authentication:

```json
{
  "rules": {
    "rooms": {
      "$room": {
        ".read": "auth != null",
        ".write": "auth != null"
      }
    }
  }
}
```

**Cảnh báo:** quy tắc này cho phép bất kỳ người đã đăng nhập ẩn danh nào đọc/ghi phòng. Chỉ dùng để thử với người quen, không lưu thông tin cá nhân. Nó không chống gian lận; người am hiểu có thể sửa điểm hoặc dữ liệu. Không dùng cho giải đấu hay dữ liệu quan trọng. Khi đã xác nhận chạy được, nên chuyển sang rules giới hạn thành viên và Cloud Functions để server tự kiểm tra đáp án, chấm điểm và đổi câu.

## 4. Đưa web lên mạng bằng Firebase Hosting
Cách chuẩn dùng máy tính:
1. Cài Node.js LTS từ https://nodejs.org/
2. Mở terminal/cmd và chạy:
   ```bash
   npm install -g firebase-tools
   firebase login
   ```
3. Tạo thư mục mới, đặt `index.html` vào trong đó.
4. Trong thư mục đó chạy:
   ```bash
   firebase init hosting
   ```
   Chọn project vừa tạo, thư mục public (nếu hỏi) nhập `public`; nếu vậy hãy đặt `index.html` vào thư mục `public`. Chọn cấu hình single-page app = No, không ghi đè file index của ông.
5. Chạy:
   ```bash
   firebase deploy
   ```
6. Firebase in ra URL dạng `https://TEN-PROJECT.web.app`. Gửi URL đó cho Hạnh. Một người tạo phòng, gửi mã phòng cho người còn lại.

## 5. Chơi
- Cả hai mở cùng URL.
- Mỗi người nhập tên riêng.
- Người thứ nhất bấm **Tạo phòng** và gửi mã 6 ký tự cho người thứ hai.
- Người thứ hai nhập mã và bấm **Vào phòng**.
- Chủ phòng bấm **Bắt đầu trận** khi đủ 2 người.
- Mỗi người nhận một bộ 8 câu hỏi khác nhau. Mỗi câu đúng +100 điểm, sai +0. Hai người trả lời xong thì chuyển câu. Cuối ván web công bố người thắng.

## Lưu ý về bản mẫu
- Đây là prototype để học và chơi vui. Nó đồng bộ phòng qua Firebase thật sau khi cấu hình, nhưng cách chấm điểm hiện ở client nên chưa chống gian lận.
- Nếu người chơi đóng tab giữa ván, phòng có thể bị bỏ dở. Có thể nâng cấp thêm nút chủ phòng khởi động lại, thời gian giới hạn, xáo câu hỏi, nhiều chủ đề, xác minh thành viên, Cloud Functions chấm điểm server-side.
- Không gửi khóa riêng tư hoặc mật khẩu. Firebase web config là cấu hình ứng dụng phía client; bảo vệ dữ liệu bằng Security Rules.
